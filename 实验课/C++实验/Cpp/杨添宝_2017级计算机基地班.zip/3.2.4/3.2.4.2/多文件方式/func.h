double fn(int n);
int Cnr(int n, int r);
