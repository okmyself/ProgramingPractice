//#include<iostream>
//using namespace std;
//int main(void)
//{
//    int operand1, operand2;
//    char op;
//    cout << "please input arithmetic expression: ";
//    cin >> operand1 >> op >> operand2;
//    while(!(operand1 == 0 && op == '0' && operand2 == 0))
//    {
//        double result;
//        switch(op)
//        {
//            case '+':
//            {
//                result = operand1 + operand2;
//                break;
//            }
//            case '-':
//            {
//                result = operand1 - operand2;
//                break;
//            }
//            case '*':
//            {
//                result = operand1 * operand2;
//                break;
//            }
//            case '/':
//            {
//                result = operand1 / operand2;
//                break;
//            }
//        }
//        cout << operand1 << op << operand2 << '=' << result << endl;
//        cout << "please input arithmetic expression: ";
//        cin >> operand1 >> op >> operand2;
//    }
//    return 0;
//}
